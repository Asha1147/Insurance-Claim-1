package com.cg.oicr.bean;

public class Question {
	private String question_Id;
	private String question_Name;
	public String getQuestion_Id() {
		return question_Id;
	}
	public void setQuestion_Id(String question_Id) {
		this.question_Id = question_Id;
	}
	public String getQuestion_Name() {
		return question_Name;
	}
	public void setQuestion_Name(String question_Name) {
		this.question_Name = question_Name;
	}

}
