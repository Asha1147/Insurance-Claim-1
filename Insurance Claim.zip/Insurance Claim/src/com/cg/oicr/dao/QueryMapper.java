package com.cg.oicr.dao;

public interface QueryMapper {
	String USER_DETAILS=" select username,password from user_role";
	String ROLECODE="select rolecode from user_role where username=? and password=?";
	String RETRIVE_USERNAME="select username from user_role";
	String INSERT_USER="INSERT INTO user_role VALUES(?,?,?)";
	
	
	String QUESTION_ONE="select questionid,question from question where questionid between '1.1' and '1.5'";
	String QUESTION_TWO="select questionid,question from question where questionid between '2.1' and '2.5'";
	String QUESTION_THREE="select questionid,question from question where questionid between '3.1' and '3.5'";
	String QUESTION_FOUR="select questionid,question from question where questionid between '4.1' and '4.5'";
	String QUESTION_FIVE="select questionid,question from question where questionid between '5.1' and '5.5'";
	
	String INSERT_POLICY_DETAILS="insert into policy_details values(?,?,?)";
	String RETRIVE_POLICIES="select * from policy where accountnumber in (select accountnumber from account where username=?)";
	String RETRIVE_POLICY_DETAILS="select questionid,answer from policy_details where policynumber=?";
	
	String INSERT_AGENT_USER="insert into agent values(?,?)";
	String CHECK_AGENT_USER="select userid from agent where agentid=?";
	
	String INSERT_CLAIM="insert into claim values(claim_number.nextval,?,?,?,?,?,?,?)";
	String RETRIVE_CURRVAL="select claim_number.currval from claim";
	String RETRIVE_CLAIM="select claimnumber,policynumber,claimtype from claim where claimnumber=?";
	String RETRIVE_CLAIM_DETAILS="select * from claim where claimnumber=?";
	
}
